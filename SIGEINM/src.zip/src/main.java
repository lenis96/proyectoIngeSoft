/*************************************************

Nombre de la clase: main.java

�ltima modificaci�n: 06/06/2016

Descripci�n: Clase sencilla para lanzar la aplicaci�n.

*************************************************/
import java.sql.*;
public class main {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ControladorGestionUsuarios a=new ControladorGestionUsuarios();
	}

}

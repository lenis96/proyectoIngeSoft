create database SIGEINM;
create user 'SIGEINM'@'%' identified by 'SIGEINM';
grant all on SIGEINM.* to 'SIGEINM';